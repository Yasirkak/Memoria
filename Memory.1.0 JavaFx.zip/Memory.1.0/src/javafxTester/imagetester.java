package javafxTester;
import javafx.animation.FadeTransition;
import javafx.animation.Transition;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;
import javafx.scene.image.Image;

import java.awt.*;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class imagetester extends Application {
    public int num_of_pair = 8;
    public int num_of_rows = 4;
    public int max_clicks;
    private Image image = new Image("/images/");
    public static void main(String[] args) {
        launch(args);
    }
    private Parent createContent(){
    Pane pane = new Pane();
    pane.setPrefSize(200,200);

    List<Tile> tile = new ArrayList<>();

    for (int i = 0; i < num_of_pair; i++) {
        tile.add(new Tile());
        tile.add(new Tile());
    }
    Collections.shuffle(tile);

    for (int i = 0; i < tile.size();i++){
        Tile tile1 = tile.get(i);
        tile1.setTranslateX(50*(i%num_of_rows));
        tile1.setTranslateY(50*(i/num_of_rows));
        pane.getChildren().add(tile1);
    }
    return pane;
    }
    private class Tile extends StackPane{
        private Image image = new Image("/images/0.PNG");
        public void allPics(){
            for (int i = 0; i < num_of_pair; i++){

            }
        }
        public Tile(){
            Rectangle rectangle = new Rectangle(50,50);
            rectangle.setFill(Color.WHEAT);
            rectangle.setStroke(Color.BLACK);

            getChildren().addAll(rectangle);
            setOnMouseClicked(e ->{
                rectangle.setFill(new ImagePattern(image));
                if (image.getPixelReader() == image.getPixelReader()){
                    System.out.println("works");
                }
                else System.out.println("fuckome");
            });




        }
    }

    @Override public void start(Stage stage) {
        stage.setScene(new Scene(createContent()));
        stage.show();
        stage.setTitle("shaoloma");

    }
}

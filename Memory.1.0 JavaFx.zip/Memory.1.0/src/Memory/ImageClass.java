package Memory;


import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class ImageClass extends Application {
    Stage window;
    public static void main(String[] args) {
        launch(args);
    }


    @Override
    public void start(Stage stage) throws Exception {
        window = stage;

        window.show();
        window.setTitle("ImageTester");

        Image image = new Image("images/1.PNG");

        ImageView imageView = new ImageView();
        imageView.setImage(image);


        Group group = new Group();
        Scene scene = new Scene(group);

        HBox layout = new HBox();
        layout.getChildren().add(imageView);
        group.getChildren().add(layout);
        window.setScene(scene);


    }
}

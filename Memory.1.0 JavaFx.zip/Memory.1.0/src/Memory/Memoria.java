package Memory;

import javafx.animation.FadeTransition;
import javafx.animation.Transition;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;
import javafx.scene.image.Image;

import java.awt.*;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class Memoria extends Application{
    public int num_Of_Pair = 8;
    public int num_Of_Rows = 4;
    public Tile selected = null;


    public static void main(String[] args) {
        launch(args);
    }
    private Parent createContent(){
        Pane pane = new Pane();
        pane.setPrefSize(200,200);
        pane.setStyle("-fx-background-color: purple;");

        List<Tile> tile = new ArrayList<>();
//        List<File> tile = new ArrayList<>();
        char c = 'A';
        for (int i = 0; i < num_Of_Pair; i++){
            tile.add(new Tile(String.valueOf(c)));
            tile.add(new Tile(String.valueOf(c)));
            c++;
        }
        Collections.shuffle(tile);
        for (int i = 0; i < tile.size(); i++){
            Tile tile1 = tile.get(i);
            tile1.setTranslateX(50 * (i % num_Of_Rows));
            tile1.setTranslateY(50 * (i / num_Of_Rows));
            pane.getChildren().add(tile1);
        }

        return pane;
    }
    private class Tile extends StackPane{
        private Text text = new Text();

        public Tile(String value){
            Rectangle rectangle = new Rectangle(50,50);
          //  rectangle.setFill(new ImagePattern(image));
            rectangle.setFill(Color.WHEAT);
            rectangle.setStroke(Color.BISQUE);

            text.setText(value);
            text.setFont(Font.font(30));
            //setAlignment(Pos.BOTTOM_CENTER);
            getChildren().addAll(rectangle,text);
            setOnMouseClicked(mouseEvent -> {
                if (isOpen())
                    return;
                if (selected == null){
                    selected = this;
                    open(() -> {});
                }
                else {
                    open(() ->{
                        if (!sameValue(selected)){
                            selected.close();
                            this.close();
                        }
                        selected = null;
                    });


                }
            });
            close();
        }
        public boolean isOpen(){
            return text.getOpacity() == 1;
        }
        public void open(Runnable action){
            FadeTransition fadeTransition = new FadeTransition(Duration.seconds(0.5), text);
            fadeTransition.setToValue(1);
            fadeTransition.setOnFinished(e -> action.run());
            fadeTransition.play();


        }
        public void close(){
            FadeTransition fadeTransition = new FadeTransition(Duration.seconds(0.1), text);
            fadeTransition.setToValue(0);
            fadeTransition.play();

        }
        public boolean sameValue(Tile other){
            return text.getText().equals(other.text.getText());
        }

    }
    @Override
    public void start(Stage stage) throws Exception {
        stage.setScene(new Scene(createContent()));
        stage.show();
        stage.setTitle("Memoria");


    }
}
